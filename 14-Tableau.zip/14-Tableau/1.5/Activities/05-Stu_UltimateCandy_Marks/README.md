# The Ultimate Candy

## Instructions

* Create a pair of bar graphs that chart the win percent of each candy, then color the bars according to whether they are fruity and/or chocolatey.

* Create a scatter plot comparing the sugar percentage against the win percentage. Color the points based upon whether they are chocolatey and size them according to price.

* Create another scatter plot comparing the sugar percentage against the win percentage. Color the points based upon whether they are fruity and size them according to price.

---

© 2021 Trilogy Education Services, LLC, a 2U, Inc. brand.  Confidential and Proprietary.  All Rights Reserved.